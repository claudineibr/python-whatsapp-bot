import { WhatsAppInterface } from "@/components/whatsapp-interface"

export default function Home() {
  return (
    <main className="min-h-screen">
      <WhatsAppInterface />
    </main>
  )
}
