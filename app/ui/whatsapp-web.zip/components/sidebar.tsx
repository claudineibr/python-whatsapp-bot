"use client"

import { Search, MoreVertical, Archive, Users, FlagIcon as Status, MessageSquare } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"

const conversations = [
  {
    id: "1",
    name: "João Silva",
    avatar: "/placeholder.svg?height=200&width=200",
    lastMessage: "Olá, tudo bem?",
    time: "10:30",
    unread: 2,
  },
  {
    id: "2",
    name: "Maria Oliveira",
    avatar: "/placeholder.svg?height=200&width=200",
    lastMessage: "Vamos nos encontrar amanhã?",
    time: "09:15",
    unread: 0,
  },
  {
    id: "3",
    name: "Pedro Santos",
    avatar: "/placeholder.svg?height=200&width=200",
    lastMessage: "Obrigado pela ajuda!",
    time: "Ontem",
    unread: 0,
  },
  {
    id: "4",
    name: "Ana Costa",
    avatar: "/placeholder.svg?height=200&width=200",
    lastMessage: "Já viu o novo filme?",
    time: "Ontem",
    unread: 1,
  },
  {
    id: "5",
    name: "Carlos Ferreira",
    avatar: "/placeholder.svg?height=200&width=200",
    lastMessage: "Reunião confirmada para segunda-feira",
    time: "Sábado",
    unread: 0,
  },
  {
    id: "6",
    name: "Família",
    avatar: "/placeholder.svg?height=200&width=200",
    lastMessage: "Mãe: Não esqueça do almoço de domingo",
    time: "Sexta",
    unread: 0,
  },
]

interface SidebarProps {
  onSelectChat: (chat: any) => void
  selectedChatId: string | undefined
  toggleMobileMenu: () => void
}

export function Sidebar({ onSelectChat, selectedChatId, toggleMobileMenu }: SidebarProps) {
  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center justify-between p-3 bg-[#f0f2f5]">
        <Avatar className="h-10 w-10">
          <AvatarImage src="/placeholder.svg?height=200&width=200" alt="Seu perfil" />
          <AvatarFallback>ME</AvatarFallback>
        </Avatar>
        <div className="flex items-center space-x-2">
          <Button variant="ghost" size="icon" className="rounded-full">
            <Users className="h-5 w-5 text-[#54656f]" />
          </Button>
          <Button variant="ghost" size="icon" className="rounded-full">
            <Status className="h-5 w-5 text-[#54656f]" />
          </Button>
          <Button variant="ghost" size="icon" className="rounded-full">
            <MessageSquare className="h-5 w-5 text-[#54656f]" />
          </Button>
          <Button variant="ghost" size="icon" className="rounded-full">
            <MoreVertical className="h-5 w-5 text-[#54656f]" />
          </Button>
        </div>
      </div>

      {/* Search */}
      <div className="p-2 bg-white">
        <div className="relative">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
            <Search className="h-5 w-5 text-[#54656f]" />
          </div>
          <Input
            type="text"
            placeholder="Pesquisar ou começar uma nova conversa"
            className="pl-10 bg-[#f0f2f5] border-none h-9 rounded-lg"
          />
        </div>
      </div>

      {/* Archived */}
      <div className="flex items-center p-3 hover:bg-[#f0f2f5] cursor-pointer">
        <Archive className="h-5 w-5 text-[#54656f] mr-3" />
        <span className="text-sm">Arquivadas</span>
      </div>

      {/* Conversations */}
      <div className="flex-1 overflow-y-auto">
        {conversations.map((chat) => (
          <div
            key={chat.id}
            className={`flex items-center p-3 cursor-pointer hover:bg-[#f0f2f5] ${
              selectedChatId === chat.id ? "bg-[#f0f2f5]" : ""
            }`}
            onClick={() => {
              onSelectChat({
                id: chat.id,
                name: chat.name,
                avatar: chat.avatar,
                lastSeen: chat.id === "1" ? "online" : "visto por último hoje às 12:45",
              })
              toggleMobileMenu()
            }}
          >
            <Avatar className="h-12 w-12 mr-3">
              <AvatarImage src={chat.avatar || "/placeholder.svg"} alt={chat.name} />
              <AvatarFallback>{chat.name.substring(0, 2).toUpperCase()}</AvatarFallback>
            </Avatar>
            <div className="flex-1 min-w-0">
              <div className="flex justify-between items-center">
                <h3 className="text-sm font-medium truncate">{chat.name}</h3>
                <span className={`text-xs ${chat.unread > 0 ? "text-[#25D366]" : "text-gray-500"}`}>{chat.time}</span>
              </div>
              <div className="flex justify-between items-center">
                <p className="text-sm text-gray-500 truncate">{chat.lastMessage}</p>
                {chat.unread > 0 && (
                  <span className="bg-[#25D366] text-white rounded-full h-5 w-5 flex items-center justify-center text-xs">
                    {chat.unread}
                  </span>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
