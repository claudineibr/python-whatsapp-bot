"use client"

import { useState } from "react"
import { ChatArea } from "./chat-area"
import { Sidebar } from "./sidebar"

export function WhatsAppInterface() {
  const [selectedChat, setSelectedChat] = useState<{
    id: string
    name: string
    avatar: string
    lastSeen: string
  } | null>({
    id: "1",
    name: "João Silva",
    avatar: "/placeholder.svg?height=200&width=200",
    lastSeen: "online",
  })

  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const toggleMobileMenu = () => {
    setIsMobileMenuOpen(!isMobileMenuOpen)
  }

  return (
    <div className="flex h-screen bg-[#f0f2f5]">
      <div
        className={`${
          isMobileMenuOpen ? "block" : "hidden"
        } md:block md:w-[30%] lg:w-[25%] h-full border-r border-gray-300 bg-white`}
      >
        <Sidebar onSelectChat={setSelectedChat} selectedChatId={selectedChat?.id} toggleMobileMenu={toggleMobileMenu} />
      </div>
      <div className="flex-1 h-full">
        {selectedChat ? (
          <ChatArea chat={selectedChat} toggleMobileMenu={toggleMobileMenu} isMobileView={!isMobileMenuOpen} />
        ) : (
          <div className="flex items-center justify-center h-full bg-[#f0f2f5]">
            <div className="text-center text-gray-500">
              <h2 className="text-xl font-medium mb-2">WhatsApp Web</h2>
              <p>Selecione uma conversa para começar a enviar mensagens.</p>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}
