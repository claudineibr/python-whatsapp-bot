"use client"

import type React from "react"

import { useState } from "react"
import { Search, MoreVertical, Smile, Paperclip, Mic, Send, ChevronLeft } from "lucide-react"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"

interface Message {
  id: string
  text: string
  time: string
  isMe: boolean
}

interface ChatAreaProps {
  chat: {
    id: string
    name: string
    avatar: string
    lastSeen: string
  }
  toggleMobileMenu: () => void
  isMobileView: boolean
}

export function ChatArea({ chat, toggleMobileMenu, isMobileView }: ChatAreaProps) {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: "Olá, tudo bem?",
      time: "10:30",
      isMe: false,
    },
    {
      id: "2",
      text: "Oi! Tudo ótimo e com você?",
      time: "10:32",
      isMe: true,
    },
    {
      id: "3",
      text: "Estou bem também! Vamos marcar algo para o final de semana?",
      time: "10:33",
      isMe: false,
    },
    {
      id: "4",
      text: "Claro! Podemos ir ao cinema no sábado, o que acha?",
      time: "10:35",
      isMe: true,
    },
    {
      id: "5",
      text: "Perfeito! Tem algum filme em mente?",
      time: "10:36",
      isMe: false,
    },
  ])

  const [newMessage, setNewMessage] = useState("")

  const handleSendMessage = () => {
    if (newMessage.trim() === "") return

    const now = new Date()
    const hours = now.getHours().toString().padStart(2, "0")
    const minutes = now.getMinutes().toString().padStart(2, "0")
    const time = `${hours}:${minutes}`

    const message: Message = {
      id: Date.now().toString(),
      text: newMessage,
      time,
      isMe: true,
    }

    setMessages([...messages, message])
    setNewMessage("")
  }

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") {
      handleSendMessage()
    }
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="flex items-center p-3 bg-[#f0f2f5] border-l border-gray-300">
        {isMobileView && (
          <Button variant="ghost" size="icon" className="mr-2" onClick={toggleMobileMenu}>
            <ChevronLeft className="h-5 w-5 text-[#54656f]" />
          </Button>
        )}
        <Avatar className="h-10 w-10 mr-3">
          <AvatarImage src={chat.avatar || "/placeholder.svg"} alt={chat.name} />
          <AvatarFallback>{chat.name.substring(0, 2).toUpperCase()}</AvatarFallback>
        </Avatar>
        <div className="flex-1">
          <h2 className="text-base font-medium">{chat.name}</h2>
          <p className="text-xs text-gray-500">{chat.lastSeen}</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button variant="ghost" size="icon" className="rounded-full">
            <Search className="h-5 w-5 text-[#54656f]" />
          </Button>
          <Button variant="ghost" size="icon" className="rounded-full">
            <MoreVertical className="h-5 w-5 text-[#54656f]" />
          </Button>
        </div>
      </div>

      {/* Messages */}
      <div
        className="flex-1 overflow-y-auto p-4 bg-[#e5ddd5]"
        style={{
          backgroundImage:
            "url('data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABQAAAAUCAIAAAAC64paAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyJpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMy1jMDExIDY2LjE0NTY2MSwgMjAxMi8wMi8wNi0xNDo1NjoyNyAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNiAoV2luZG93cykiIHhtcE1NOkluc3RhbmNlSUQ9InhtcC5paWQ6NzVBRUUzOEI4OTZDMTFFQTk1Q0FCNUU0MTlENzZBQTMiIHhtcE1NOkRvY3VtZW50SUQ9InhtcC5kaWQ6NzVBRUUzOEM4OTZDMTFFQTk1Q0FCNUU0MTlENzZBQTMiPiA8eG1wTU06RGVyaXZlZEZyb20gc3RSZWY6aW5zdGFuY2VJRD0ieG1wLmlpZDo3NUFFRTM4OTg5NkMxMUVBOTVDQUI1RTQxOUQ3NkFBMyIgc3RSZWY6ZG9jdW1lbnRJRD0ieG1wLmRpZDo3NUFFRTM4QTg5NkMxMUVBOTVDQUI1RTQxOUQ3NkFBMyIvPiA8L3JkZjpEZXNjcmlwdGlvbj4gPC9yZGY6UkRGPiA8L3g6eG1wbWV0YT4gPD94cGFja2V0IGVuZD0iciI/PvBpo2wAAABMSURBVHjaYkxOTmZAAhMTEwwMDEgCjIyMyAIsMBZYAQwjC8DQqCCKACMj4////1FEYAZ+/fpFjAA2S4l3OgMDw6giRhUxYBQBBBgAB8Yqe9Fd2qYAAAAASUVORK5CYII=')",
          backgroundRepeat: "repeat",
        }}
      >
        {messages.map((message) => (
          <div key={message.id} className={`flex ${message.isMe ? "justify-end" : "justify-start"} mb-4`}>
            <div className={`max-w-[65%] rounded-lg p-3 relative ${message.isMe ? "bg-[#dcf8c6]" : "bg-white"}`}>
              <p className="text-sm">{message.text}</p>
              <span className="text-[10px] text-gray-500 block text-right mt-1">{message.time}</span>
            </div>
          </div>
        ))}
      </div>

      {/* Input */}
      <div className="p-3 bg-[#f0f2f5] flex items-center">
        <Button variant="ghost" size="icon" className="rounded-full">
          <Smile className="h-6 w-6 text-[#54656f]" />
        </Button>
        <Button variant="ghost" size="icon" className="rounded-full">
          <Paperclip className="h-6 w-6 text-[#54656f]" />
        </Button>
        <div className="flex-1 mx-2">
          <Input
            type="text"
            placeholder="Digite uma mensagem"
            className="bg-white rounded-lg border-none"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
          />
        </div>
        <Button variant="ghost" size="icon" className="rounded-full">
          {newMessage.trim() === "" ? (
            <Mic className="h-6 w-6 text-[#54656f]" />
          ) : (
            <Send className="h-6 w-6 text-[#54656f]" onClick={handleSendMessage} />
          )}
        </Button>
      </div>
    </div>
  )
}
